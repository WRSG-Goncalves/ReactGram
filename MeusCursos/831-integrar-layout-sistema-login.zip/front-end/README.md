COMO RODAR O PROJETO BAIXADO
Instalar todas as dependencias indicada pelo package.json
### npm install

Rodar o projeto React 
### npm start


SEQUENCIA PARA CRIAR O PROJETO
Criar o projeto React - https://pt-br.reactjs.org/docs/create-a-new-react-app.html
### npx create-react-app my-app

Acessar o diretório do projeto
### cd my-app

Rodar o projeto React 
### npm start

Gerenciar as rotas
### npm install react-router-dom

Realizar chamada para API
### npm install --save axios

Utilizado para mudar de página e renderizar a nova página sem recarregar toda aplicação
### npm install --save history@4.10.1

Validar campo do formulário
### npm install --save yup
