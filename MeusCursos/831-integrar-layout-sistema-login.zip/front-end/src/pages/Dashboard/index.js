import React from 'react';
import { Menu } from '../../components/Menu';

export const Dashboard = () => {
    return (
        <div>
            <Menu />
            <h1>Dashboard</h1>
        </div>
    );
}