function Home() {
    return <div>Welcome to Celke!</div>
}

export default Home;