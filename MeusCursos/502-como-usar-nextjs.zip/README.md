COMO RODAR O PROJETO BAIXADO
Instalar todas as dependencias indicada pelo package.json
### npm install

Rodar o projeto
### npm run dev



SEQUENCIA PARA CRIAR O PROJETO
Criar o arquivo package
### npm init

Criar o projeto com Next.js
### npm install next react react-dom

Rodar o projeto 
### npm run dev

Acessar o projeto no navegador
### http://localhost:3000
